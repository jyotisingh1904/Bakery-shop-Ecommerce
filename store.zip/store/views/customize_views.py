from django.shortcuts import render

def customize_page(request):
    return render(request, 'store/customize_page.html')

# You can define more views related to customization here
